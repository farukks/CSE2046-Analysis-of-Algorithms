package Sorting;
import java.util.Arrays;
import java.util.Collections;
public class Idea {

			public static void main(String[] args){
				int[] arr= {45,
						78,
						156,
						95,
						12,
						16,
						189,
						2,
						8,
						18,
						102};	
				for(int i=0;i<arr.length-3;i++) {
					System.out.println(arr[i]);
				}
			}
		


	}


